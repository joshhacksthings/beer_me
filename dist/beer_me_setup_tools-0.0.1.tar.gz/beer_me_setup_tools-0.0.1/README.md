# Beer Me
A Flask-based app for recording the beers you've had

[![Build Status](https://travis-ci.com/joshhacksthings/beer_me.svg?branch=master)](https://travis-ci.com/joshhacksthings/beer_me)
## About
An easy-to-use log of all of the delicious beer you drink.